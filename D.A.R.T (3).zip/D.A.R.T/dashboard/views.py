
# import requests # Add this import at the top of the file
# from django.shortcuts import render, redirect
# from django.contrib.auth.decorators import login_required
# from django.contrib import messages
# from django.urls import reverse
# from django.views.decorators.clickjacking import xframe_options_sameorigin
# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# import json
# from users.models import CustomUser

# @login_required(login_url='login_page')
# def dashboard_view(request):
#     """
#     This serves the main index.html dashboard.
#     """
#     if request.user.user_type != 'student':
#         messages.error(request, 'Access Denied. This dashboard is for students.')
#         return redirect('logout')

#     total_modules_in_project = 3
#     modules_done = request.user.modules_completed

#     if modules_done > total_modules_in_project:
#          modules_done = total_modules_in_project

#     progress_percent = 0
#     if total_modules_in_project > 0 and modules_done > 0:
#         progress_percent = int((modules_done / total_modules_in_project) * 100)

#     leaderboard_users = CustomUser.objects.order_by('-total_points')[:5]

#     # --- Fetches Weather Data ---
#     weather_data = {}
#     try:
#         api_key = '6f95c36c3e5526cea53c95a92555fc3b' # <-- PASTE YOUR API KEY HERE
#         city = 'Vadodara'
#         url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'
#         response = requests.get(url)
#         data = response.json()

#         if response.status_code == 200:
#             weather_data = {
#                 'temperature': data['main']['temp'],
#                 'description': data['weather'][0]['description'].title(),
#                 'icon': data['weather'][0]['icon'],
#             }
#     except Exception as e:
#         print(f"Could not fetch weather data: {e}")

#     context = {
#         'full_name': request.user.first_name,
#         'student_id': request.user.student_id,
#         'points': request.user.total_points,
#         'modules': modules_done,
#         'total_modules': total_modules_in_project,
#         'progress_percent': progress_percent,
#         'leaderboard_users': leaderboard_users,
#         'weather_data': weather_data,
#     }
#     return render(request, 'index.html', context)

# @login_required(login_url='login_page')
# def progress_view(request):
#     """
#     This serves the new progress.html page.
#     """
#     user = request.user
#     total_modules_in_project = 10 # Total modules available in the whole program
#     modules_done = user.modules_completed

#     # Ensure modules_done doesn't exceed the total
#     if modules_done > total_modules_in_project:
#         modules_done = total_modules_in_project

#     progress_percent = 0
#     if total_modules_in_project > 0:
#         progress_percent = int((modules_done / total_modules_in_project) * 100)

#     # Get top 5 users for the leaderboard
#     leaderboard_users = CustomUser.objects.filter(user_type='student').order_by('-total_points')[:5]
    
#     # Data for the charts
#     bar_chart_data = {
#         'labels': ['Lesson 1', 'Lesson 2', 'Lesson 3'],
#         'data': [50, 100, 0] 
#     }
#     pie_chart_data = {
#         'completed': modules_done,
#         'remaining': total_modules_in_project - modules_done
#     }
    
#     context = {
#         'full_name': user.first_name,
#         'points': user.total_points,
#         'modules': modules_done,
#         'total_modules': total_modules_in_project,
#         'progress_percent': progress_percent,
#         'leaderboard_users': leaderboard_users,
#         'bar_chart_data': bar_chart_data,
#         'pie_chart_data': pie_chart_data,
#         'request': request
#     }
#     return render(request, 'progress.html', context)


# @xframe_options_sameorigin
# def chatbot_view(request):
#     """
#     This view simply serves your intel.html chatbot page.
#     """
#     return render(request, 'intel.html')

# @login_required(login_url='login_page')
# def lesson_two_view(request):
#     """
#     This view serves your hard-coded lesson page 'two.html'.
#     """
#     xp_awarded = request.session.pop('xp_awarded_lesson_2', False)
#     return render(request, 'two.html', {'xp_awarded': xp_awarded})

# @login_required(login_url='login_page')
# def complete_lesson_1_view(request):
#     # This function is for "Lesson 1: Secure Your Space"
#     user = request.user
#     user.total_points += 50
#     user.modules_completed += 1
#     user.save()

#     messages.success(request, 'Lesson 1 Complete! +50 Points!')
#     return redirect('dashboard')

# @login_required(login_url='login_page')
# def get_xp_view(request):
#     # This function is for "Lesson 2: Go-Bag Essentials" - awarding XP
#     user = request.user
#     user.total_points += 100
#     user.save()
#     messages.success(request, 'You earned 100 XP!')
#     request.session['xp_awarded_lesson_2'] = True
#     return redirect('lesson-two')

# @csrf_exempt
# @login_required(login_url='login_page')
# def quiz_results_view(request):
#     if request.method == 'POST':
#         data = json.loads(request.body)
#         score = data.get('score', 0)
#         total_questions = data.get('total_questions', 5)

#         xp_earned = int((score / total_questions) * 100)

#         user = request.user
#         user.total_points += xp_earned
#         user.modules_completed += 1  # This correctly marks the module as complete
#         user.save()

#         messages.success(request, f'Quiz Complete! You earned {xp_earned} XP!')
#         return JsonResponse({'status': 'success', 'xp_earned': xp_earned})
#     return JsonResponse({'status': 'error'}, status=400)

import requests # Add this import at the top of the file
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.views.decorators.clickjacking import xframe_options_sameorigin
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from users.models import CustomUser

@login_required(login_url='login_page')
def dashboard_view(request):
    """
    This serves the main index.html dashboard.
    """
    if request.user.user_type != 'student':
        messages.error(request, 'Access Denied. This dashboard is for students.')
        return redirect('logout')

    total_modules_in_project = 3
    modules_done = request.user.modules_completed

    if modules_done > total_modules_in_project:
         modules_done = total_modules_in_project

    progress_percent = 0
    if total_modules_in_project > 0 and modules_done > 0:
        progress_percent = int((modules_done / total_modules_in_project) * 100)

    leaderboard_users = CustomUser.objects.order_by('-total_points')[:5]

    # --- Fetches Weather Data ---
    weather_data = {}
    try:
        api_key = '6f95c36c3e5526cea53c95a92555fc3b' # <-- PASTE YOUR API KEY HERE
        city = 'Vadodara'
        url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'
        response = requests.get(url)
        data = response.json()

        if response.status_code == 200:
            weather_data = {
                'temperature': data['main']['temp'],
                'description': data['weather'][0]['description'].title(),
                'icon': data['weather'][0]['icon'],
            }
    except Exception as e:
        print(f"Could not fetch weather data: {e}")

    context = {
        'full_name': request.user.first_name,
        'student_id': request.user.student_id,
        'points': request.user.total_points,
        'modules': modules_done,
        'total_modules': total_modules_in_project,
        'progress_percent': progress_percent,
        'leaderboard_users': leaderboard_users,
        'weather_data': weather_data,
    }
    return render(request, 'index.html', context)

@login_required(login_url='login_page')
def progress_view(request):
    """
    This serves the new progress.html page.
    """
    user = request.user
    total_modules_in_project = 10 # Total modules available in the whole program
    modules_done = user.modules_completed

    # Ensure modules_done doesn't exceed the total
    if modules_done > total_modules_in_project:
        modules_done = total_modules_in_project

    progress_percent = 0
    if total_modules_in_project > 0:
        progress_percent = int((modules_done / total_modules_in_project) * 100)

    # Get top 5 users for the leaderboard
    leaderboard_users = CustomUser.objects.filter(user_type='student').order_by('-total_points')[:5]
    
    # Data for the charts
    bar_chart_data = {
        'labels': ['Lesson 1', 'Lesson 2', 'Lesson 3'],
        'data': [50, 100, 0] 
    }
    pie_chart_data = {
        'completed': modules_done,
        'remaining': total_modules_in_project - modules_done
    }
    
    context = {
        'full_name': user.first_name,
        'points': user.total_points,
        'modules': modules_done,
        'total_modules': total_modules_in_project,
        'progress_percent': progress_percent,
        'leaderboard_users': leaderboard_users,
        'bar_chart_data': bar_chart_data,
        'pie_chart_data': pie_chart_data,
        'request': request
    }
    return render(request, 'progress.html', context)


@xframe_options_sameorigin
def chatbot_view(request):
    """
    This view simply serves your intel.html chatbot page.
    """
    return render(request, 'intel.html')

@login_required(login_url='login_page')
def lesson_two_view(request):
    """
    This view serves your hard-coded lesson page 'two.html'.
    """
    xp_awarded = request.session.pop('xp_awarded_lesson_2', False)
    return render(request, 'two.html', {'xp_awarded': xp_awarded})

@login_required(login_url='login_page')
def complete_lesson_1_view(request):
    # This function is for "Lesson 1: Secure Your Space"
    user = request.user
    user.total_points += 50
    user.modules_completed += 1
    user.save()

    messages.success(request, 'Lesson 1 Complete! +50 Points!')
    return redirect('dashboard')

@login_required(login_url='login_page')
def get_xp_view(request):
    # This function is for "Lesson 2: Go-Bag Essentials" - awarding XP
    user = request.user
    user.total_points += 100
    user.save()
    messages.success(request, 'You earned 100 XP!')
    request.session['xp_awarded_lesson_2'] = True
    return redirect('lesson-two')

@csrf_exempt
@login_required(login_url='login_page')
def quiz_results_view(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        score = data.get('score', 0)
        total_questions = data.get('total_questions', 5)

        xp_earned = int((score / total_questions) * 100)

        user = request.user
        user.total_points += xp_earned
        user.modules_completed += 1  # This correctly marks the module as complete
        user.save()

        messages.success(request, f'Quiz Complete! You earned {xp_earned} XP!')
        return JsonResponse({'status': 'success', 'xp_earned': xp_earned})
    return JsonResponse({'status': 'error'}, status=400)

@login_required(login_url='login_page')
def complete_lesson_2_view(request):
    # This function is for "Lesson 2: Go-Bag Essentials"
    user = request.user

    user.total_points += 100 
    user.modules_completed += 1
    user.save() 

    messages.success(request, 'Lesson 2 Complete! +100 Points!')
    return redirect('/#modules')


# New view to serve new2.html for the Hurricane drill
@xframe_options_sameorigin
@login_required(login_url='login_page')
def hurricane_drill_view(request):
    return render(request, 'new2.html')
