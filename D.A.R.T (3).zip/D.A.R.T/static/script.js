const disasterTips = {
  earthquake: "During an earthquake: Drop, Cover, and Hold On. Stay away from windows and heavy objects. After shaking stops, move to an open area. ",
  flood: "In case of floods: Move to higher ground immediately. Avoid walking or driving through flood waters. Disconnect electrical appliances.",
  fire: "If there’s a fire: Stay low to avoid smoke, use the stairs not the lift, and cover nose/mouth with a wet cloth.",
  cyclone: "For cyclones: Stay indoors, close windows, stock emergency supplies, and keep a battery-powered radio.",
  covid: "For COVID-19: Wear masks, maintain social distancing, wash hands frequently, and follow local health advisories.",
  tsunami: "If tsunami warning: Move to higher ground immediately. Stay away from beaches. Follow official alerts strictly."
};


// NEW: disaster details (definitions + causes)
const disasterDetails = {
  earthquake: " An earthquake is the shaking of the Earth caused by sudden movements of tectonic plates beneath the surface. They can cause buildings to collapse, landslides, and tsunamis. Magnitude is measured on the Richter scale.",
  flood: " A flood is an overflow of water onto land that is normally dry. It can be caused by heavy rains, river overflow, or dam failures. Floods can damage homes, crops, and infrastructure.",
  fire: "A fire is the rapid oxidation of materials producing heat, light, and smoke. It may occur in homes, forests, or industries. Major causes include electrical faults, open flames, and accidents.",
  cyclone: " A cyclone is a large-scale air mass that rotates around a strong center of low atmospheric pressure. They bring heavy rainfall, strong winds, and can cause flooding and destruction.",
  covid: " COVID-19 is an infectious disease caused by the SARS-CoV-2 virus. It spreads through respiratory droplets and can cause fever, cough, breathing problems, and severe illness in vulnerable groups.",
  tsunami: " A tsunami is a series of large ocean waves usually caused by underwater earthquakes, volcanic eruptions, or landslides. They can flood coastal areas and cause massive destruction."
};


const disasterSafePlaces = {
  earthquake: " During an earthquake: Stay under sturdy furniture like a table or desk. If outdoors, move to an open area away from buildings, trees, and power lines.",
  flood: "During floods: Move to higher ground or the top floor of a strong building. Stay away from bridges and flooded roads.",
  fire: " In case of fire: Move outside to an open safe zone. Do not use elevators, use stairs. Stay away from smoke-filled areas.",
  cyclone: " For cyclones: Take shelter in a basement or small interior room with no windows. If outdoors, lie flat in a ditch or low-lying area away from trees.",
  covid: " For COVID-19: Safe places are open, well-ventilated areas. Avoid crowded indoor places and maintain physical distancing.",
  tsunami: "For tsunami: Move to higher ground or tall strong buildings immediately. Stay away from beaches and coastal areas."
};

// Levenshtein distance (spell correction)
function levenshtein(a, b) {
  const matrix = Array.from({ length: a.length + 1 }, () => []);
  for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
  for (let j = 0; j <= b.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      if (a[i - 1] === b[j - 1]) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[a.length][b.length];
}

// Find closest matching keyword for a single word
function correctWord(input, keywords) {
  let minDist = Infinity, closest = null;
  keywords.forEach(word => {
    const dist = levenshtein(input, word);
    if (dist < minDist) {
      minDist = dist;
      closest = word;
    }
  });
  // return only if it's reasonably close (typo tolerance)
  return minDist <= 3 ? closest : null;
}

// Typing effect
function typeEffect(text, element, speed = 35) {
  let i = 0;
  element.innerHTML = "";
  const interval = setInterval(() => {
    if (i < text.length) {
      element.innerHTML += text.charAt(i);
      i++;
    } else {
      clearInterval(interval);
    }
  }, speed);
}

function getAnswer() {
  const inputField = document.getElementById("userInput");
  const input = inputField.value.toLowerCase().trim();
  const resultBox = document.getElementById("result");

  if (!input) {
    resultBox.innerHTML = "👉 Please type a question first!";
    return;
  }

  // Clear input box
  inputField.value = "";

  // Show user's question
  resultBox.innerHTML = `<div class="user-question">🙋‍♂️ You: ${input}</div><div class="ai-answer"><i class='fa-solid fa-robot text-info'></i> Thinking...</div>`;

  setTimeout(() => {
    let response = "🤔 I don’t have information on that. Please ask about earthquake, flood, fire, cyclone, tsunami, or COVID.";

    const words = input.split(/\s+/);
    let bestMatch = null;
    let bestDist = Infinity;

    for (let word of words) {
      const corrected = correctWord(word, Object.keys(disasterTips));
      if (corrected) {
        const dist = levenshtein(word, corrected);
        if (dist < bestDist) {
          bestDist = dist;
          bestMatch = corrected;
        }
      }
    }

    if (bestMatch && disasterTips[bestMatch]) {
      response = disasterTips[bestMatch];
    }

    const aiAnswer = resultBox.querySelector(".ai-answer");
    typeEffect("💡 " + response, aiAnswer);
  }, 1000);
}

// function getAnswer() {
//   const inputField = document.getElementById("userInput");
//   const input = inputField.value.toLowerCase().trim();
//   const resultBox = document.getElementById("result");

//   if (!input) return;

//   inputField.value = "";

//   // Show user message
//   resultBox.insertAdjacentHTML("beforeend", `
//     <div class="user-question">🙋‍♂️ You: ${input}</div>
//   `);

//   const aiId = "ai-" + Date.now();
//   resultBox.insertAdjacentHTML("beforeend", `
//     <div id="${aiId}" class="ai-answer"><i class='fa-solid fa-robot text-info'></i> Thinking...</div>
//   `);
//   resultBox.scrollTop = resultBox.scrollHeight;

//   setTimeout(() => {
//     let response = "🤔 I don’t have information on that. Please ask about earthquake, flood, fire, cyclone, tsunami, or COVID.";

//     const words = input.split(/\s+/);
//     let bestMatch = null;
//     let bestDist = Infinity;

//     for (let word of words) {
//       const corrected = correctWord(word, Object.keys(disasterTips));
//       if (corrected) {
//         const dist = levenshtein(word, corrected);
//         if (dist < bestDist) {
//           bestDist = dist;
//           bestMatch = corrected;
//         }
//       }
//     }

//     if (bestMatch) {
//       // If user asks "what is ..." → show definition/details
//       if (input.includes("what is") || input.includes("define") || input.includes("about")) {
//         response = disasterDetails[bestMatch] || disasterTips[bestMatch];
//       } else {
//         // Otherwise → give safety tips
//         response = disasterTips[bestMatch];
//       }
//     }

//     if (bestMatch) {
//   if (input.includes("what is") || input.includes("define") || input.includes("about")) {
//     response = disasterDetails[bestMatch] || disasterTips[bestMatch];
//   } else if (input.includes("safe place") || input.includes("where to go") || input.includes("shelter")) {
//     response = disasterSafePlaces[bestMatch] || disasterTips[bestMatch];
//   } else {
//     response = disasterTips[bestMatch]; // default = safety tips
//   }
// }


//     const aiAnswer = document.getElementById(aiId);
//     typeEffect("💡 " + response, aiAnswer);
//     resultBox.scrollTop = resultBox.scrollHeight;
//   }, 1000);
// }
function getAnswer() {
  const inputField = document.getElementById("userInput");
  const input = inputField.value.toLowerCase().trim();
  const resultBox = document.getElementById("result");

  if (!input) return;

  inputField.value = "";

  // Show user message
  resultBox.insertAdjacentHTML("beforeend", `
    <div class="user-question">🙋‍♂️ You: ${input}</div>
  `);

  const aiId = "ai-" + Date.now();
  resultBox.insertAdjacentHTML("beforeend", `
    <div id="${aiId}" class="ai-answer"><i class='fa-solid fa-robot text-info'></i> Thinking...</div>
  `);
  resultBox.scrollTop = resultBox.scrollHeight;

  setTimeout(() => {
    let response = "🤔 I don’t have information on that. Please ask about earthquake, flood, fire, cyclone, tsunami, or COVID.";

    // ✅ Step 1: Direct match for disaster names
    let bestMatch = null;
    for (let key of Object.keys(disasterTips)) {
      if (input.includes(key)) {
        bestMatch = key;
        break;
      }
    }

    // ✅ Step 2: If no direct match, do spell correction
    if (!bestMatch) {
      const words = input.split(/\s+/);
      let bestDist = Infinity;
      for (let word of words) {
        const corrected = correctWord(word, Object.keys(disasterTips));
        if (corrected) {
          const dist = levenshtein(word, corrected);
          if (dist < bestDist) {
            bestDist = dist;
            bestMatch = corrected;
          }
        }
      }
    }

    // ✅ Step 3: Decide which type of info to show
    if (bestMatch) {
      if (input.includes("what is") || input.includes("define") || input.includes("about")) {
        response = disasterDetails[bestMatch] || disasterTips[bestMatch];
      } else if (input.includes("safe place") || input.includes("where to go") || input.includes("shelter")) {
        response = disasterSafePlaces[bestMatch] || disasterTips[bestMatch];
      } else {
        response = disasterTips[bestMatch]; // default = safety tips
      }
    }

    // Show final AI answer
    const aiAnswer = document.getElementById(aiId);
    typeEffect("💡 " + response, aiAnswer);
    resultBox.scrollTop = resultBox.scrollHeight;
  }, 1000);
  
}
// ... [existing chatbot logic] ...

function getAnswer() {
  const inputField = document.getElementById("userInput");
  const input = inputField.value.toLowerCase().trim();
  const resultBox = document.getElementById("result");
  if (!input) return;
  inputField.value = "";
  // Show user message
  resultBox.insertAdjacentHTML("beforeend", `
    <div class="user-question">  You: ${input}</div>
  `);
  const aiId = "ai-" + Date.now();
  resultBox.insertAdjacentHTML("beforeend", `
    <div id="${aiId}" class="ai-answer"><i class='fa-solid fa-robot text-info'></i> Thinking...</div>
  `);
  resultBox.scrollTop = resultBox.scrollHeight;
  setTimeout(() => {
    let response = "  I don t have information on that. Please ask about earthquake, flood, fire, cyclone, tsunami, or COVID.";
    //   Step 1: Direct match for disaster names
    let bestMatch = null;
    for (let key of Object.keys(disasterTips)) {
      if (input.includes(key)) {
        bestMatch = key;
        break;
      }
    }
    //   Step 2: If no direct match, do spell correction
    if (!bestMatch) {
      const words = input.split(/\s+/);
      let bestDist = Infinity;
      for (let word of words) {
        const corrected = correctWord(word, Object.keys(disasterTips));
        if (corrected) {
          const dist = levenshtein(word, corrected);
          if (dist < bestDist) {
            bestDist = dist;
            bestMatch = corrected;
          }
        }
      }
    }
    //   Step 3: Decide which type of info to show
    if (bestMatch) {
      if (input.includes("what is") || input.includes("define") || input.includes("about")) {
        response = disasterDetails[bestMatch] || disasterTips[bestMatch];
      } else if (input.includes("safe place") || input.includes("where to go") || input.includes("shelter")) {
        response = disasterSafePlaces[bestMatch] || disasterTips[bestMatch];
      } else {
        response = disasterTips[bestMatch]; // default = safety tips
      }
    }
    // Show final AI answer
    const aiAnswer = document.getElementById(aiId);
    typeEffect("  " + response, aiAnswer);
    resultBox.scrollTop = resultBox.scrollHeight;
  }, 1000);
}

// Start adding your new dark mode code right here, after the last closing brace.
// VVVV

// Dark mode toggle functionality
document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;

    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-mode');
        themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
    }

    // Toggle theme on button click
    themeToggle.addEventListener('click', () => {
        if (body.classList.contains('dark-mode')) {
            body.classList.remove('dark-mode');
            themeToggle.innerHTML = '<i class="fa-solid fa-moon"></i>';
            localStorage.setItem('theme', 'light');
        } else {
            body.classList.add('dark-mode');
            themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
            localStorage.setItem('theme', 'dark');
        }
    });
});