from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    # These are the choices for the user_type field
    USER_TYPE_CHOICES = (
        ('student', 'Student'),
        ('admin', 'Admin'),
    )
    
    # We add our new fields here
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES, default='student')
    student_id = models.CharField(max_length=100, unique=True, null=True, blank=True)

    # --- ADD THESE TWO NEW LINES ---
    total_points = models.IntegerField(default=0)
    modules_completed = models.IntegerField(default=0)
    # --------------------------------

    def __str__(self):
        return self.username
