from django.contrib import admin
from .models import Drill, DrillParticipation

admin.site.register(Drill)
admin.site.register(DrillParticipation)