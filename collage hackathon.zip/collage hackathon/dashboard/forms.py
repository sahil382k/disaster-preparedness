# dashboard/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=[
        ('admin', 'Administrator'),
        ('principal', 'Principal'),
        ('teacher', 'Teacher'),
        ('student', 'Student')
    ])
    school = forms.CharField(max_length=100)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'role', 'school')