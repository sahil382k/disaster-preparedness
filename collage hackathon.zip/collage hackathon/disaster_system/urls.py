from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from .views import home, login_view, logout_view, register_view
from modules.views import dashboard  # Import dashboard from modules

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),  # This should be your landing page
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/', register_view, name='register'),
    path('dashboard/', dashboard, name='dashboard'),  # Directly point to dashboard view
    path('modules/', include('modules.urls')),
    path('drills/', include('drills.urls')),
    path('alerts/', include('alerts.urls')),
    path('gamification/', include('gamification.urls')),
]