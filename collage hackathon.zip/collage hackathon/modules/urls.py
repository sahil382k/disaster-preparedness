from django.urls import path
from . import views
from modules.views import drill_list,module_detail

urlpatterns = [
   
    path('manage/', views.manage_modules, name='manage_modules'),  # /dashboard/manage/
    path('drills/', drill_list, name='drill_list'),
    path('<int:pk>/', views.module_detail, name='module_detail')
]