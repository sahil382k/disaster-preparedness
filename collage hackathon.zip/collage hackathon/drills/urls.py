from django.urls import path
from . import views

urlpatterns = [
    # New URL pattern for creating a drill
    path('create/', views.create_drill, name='create_drill'),
    # Existing URL for the drill list, updated for clarity
    path('list/', views.drill_list, name='drill_list'),
]