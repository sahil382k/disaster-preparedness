from django.db import models
from django.contrib.auth.models import User

class Drill(models.Model):
    DISASTER_TYPES = [
        ('earthquake', 'Earthquake'),
        ('fire', 'Fire'),
        ('flood', 'Flood'),
        ('other', 'Other'),
    ]
    
    name = models.CharField(max_length=100)
    disaster_type = models.CharField(max_length=20, choices=DISASTER_TYPES)
    duration = models.IntegerField(help_text="Duration in minutes")
    scheduled_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_completed = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name

class DrillParticipation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    drill = models.ForeignKey(Drill, on_delete=models.CASCADE)
    score = models.IntegerField(default=0)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ('user', 'drill')

