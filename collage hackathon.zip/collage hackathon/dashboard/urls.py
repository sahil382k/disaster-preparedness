# collage hackathon/dashboard/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('student_progress/<int:pk>/', views.student_progress, name='student_progress'),
]