from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Module, Question, UserModuleProgress

@login_required
def manage_modules(request):
    return render(request, 'modules/manage_modules.html')

@login_required
def dashboard(request):
    return render(request, 'dashboard.html')  # Make sure this template exists

# Add these if they don't exist in your main views.py
def home(request):
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

def register_view(request):
    # Add registration logic here
    return render(request, 'register.html')


def drill_list(request):
    return render(request, 'drills/drill_list.html')


def create_drill(request):
    return render(request, 'drills/create_drill.html')


@login_required
def manage_modules(request):
    # Fetch all modules from the database
    modules = Module.objects.all()
    context = {'modules': modules}
    return render(request, 'modules/manage_modules.html', context)

@login_required
def module_detail(request, pk):
    # Fetch the module object or return a 404 error if it doesn't exist
    module = get_object_or_404(Module, pk=pk)

    # Get a list of questions for this module to represent lessons
    lessons = module.question_set.all().order_by('order')
    
    # Calculate user's progress for this module
    completed_lessons = UserModuleProgress.objects.filter(user=request.user, module=module, completed=True).count()
    total_lessons = lessons.count()
    progress_percentage = (completed_lessons / total_lessons) * 100 if total_lessons > 0 else 0

    context = {
        'module': module,
        'lessons': lessons,
        'completed_lessons': completed_lessons,
        'total_lessons': total_lessons,
        'progress_percentage': round(progress_percentage),
    }
    
    return render(request, 'modules/module_detail_new.html', context)
...