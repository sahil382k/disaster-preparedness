from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import CustomUser  # This imports the CustomUser model we made

def login_page_view(request):
    """
    This view serves the login.html page.
    If the user is already logged in, it redirects them to the dashboard.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')

    return render(request, 'login.html')

def student_register_view(request):
    """
    This view handles the logic for the Student Registration form.
    """
    if request.method == 'POST':
        name = request.POST.get('name')
        student_id = request.POST.get('student_id')
        username = request.POST.get('username')
        pass1 = request.POST.get('password')
        pass2 = request.POST.get('password_confirm')

        if pass1 != pass2:
            messages.error(request, 'Passwords do not match.')
            return redirect('login_page')

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'A user with this Student ID already exists.')
            return redirect('login_page')

        try:
            user = CustomUser.objects.create_user(
                username=username,       
                password=pass1,
                first_name=name,         
                student_id=student_id,
                user_type='student'      
            )
            user.save()

            messages.success(request, 'Registration successful! You may now log in.')
            return redirect('login_page')

        except Exception as e:
            messages.error(request, f'An error occurred during registration: {e}')
            return redirect('login_page')

    return redirect('login_page')


def student_login_view(request):
    """
    This view handles the logic for the Student Login form.
    """
    if request.method == 'POST':
        username = request.POST.get('username')  
        passw = request.POST.get('password')

        user = authenticate(request, username=username, password=passw)

        if user is not None:
            if user.user_type == 'student':
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'This login is for students only.')
                return redirect('login_page')
        else:
            messages.error(request, 'Invalid Student ID or password.')
            return redirect('login_page')

    return redirect('login_page')


def user_logout_view(request):
    """
    Logs the user out and sends them to the login page.
    """
    logout(request)
    return redirect('login_page')