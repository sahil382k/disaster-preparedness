from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser  # Import the CustomUser model we made

# This class tells Django how to display our new user model in the admin panel
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    
    # These lists add our new fields ('user_type', 'student_id') to the admin panel
    # so you can see them and edit them.
    list_display = ['username', 'email', 'first_name', 'last_name', 'user_type', 'student_id']
    
    fieldsets = UserAdmin.fieldsets + (
        ('Custom Fields', {'fields': ('user_type', 'student_id',)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Custom Fields', {'fields': ('user_type', 'student_id',)}),
    )

# This is the most important line: it registers our model with the admin site.
admin.site.register(CustomUser, CustomUserAdmin)