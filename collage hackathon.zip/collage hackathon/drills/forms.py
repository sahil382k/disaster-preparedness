from django import forms
from .models import Drill

class DrillForm(forms.ModelForm):
    class Meta:
        model = Drill
        fields = ['name', 'disaster_type', 'duration', 'scheduled_date']
        widgets = {
            'scheduled_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }