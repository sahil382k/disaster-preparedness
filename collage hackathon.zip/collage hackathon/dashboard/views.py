# collage hackathon/dashboard/views.py
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import UserProfile
from modules.models import UserModuleProgress, Module
from drills.models import DrillParticipation
from gamification.models import UserBadge, Badge
from django.db.models import Sum, Count, F

@login_required
def dashboard(request):
    context = {
        'preparedness': 85,
    }
    return render(request, 'dashboard.html', context)

@login_required
def student_progress(request, pk):
    # Fetch the UserProfile for the given primary key (pk) or return a 404 error
    user_profile = get_object_or_404(UserProfile, pk=pk)
    user = user_profile.user

    # Calculate module progress
    module_progress = []
    total_modules = Module.objects.all().count()
    completed_modules = UserModuleProgress.objects.filter(user=user, completed=True).count()
    
    # Get progress for each module (simplified for this example)
    modules = Module.objects.all()
    for module in modules:
        progress = UserModuleProgress.objects.filter(user=user, module=module, completed=True).count()
        completion_percentage = (progress / module.question_set.count()) * 100 if module.question_set.count() > 0 else 0
        module_progress.append({
            'title': module.title,
            'percentage': round(completion_percentage),
        })

    # Get drill scores
    drills = DrillParticipation.objects.filter(user=user).select_related('drill')

    # Get earned badges
    badges = UserBadge.objects.filter(user=user).select_related('badge')
    
    context = {
        'user_profile': user_profile,
        'user': user,
        'module_progress': module_progress,
        'drills': drills,
        'badges': badges,
        'total_modules': total_modules,
        'completed_modules': completed_modules,
        # You can add more data points like overall points, etc.
    }
    return render(request, 'gamification/student_progress.html', context)