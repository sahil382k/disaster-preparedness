# from django.contrib import admin
# from django.urls import path
# from users import views as user_views
# from dashboard import views as dash_views

# urlpatterns = [
#     path('admin/', admin.site.urls),
    
#     # Main Dashboard and Progress Page
#     path('', dash_views.dashboard_view, name='dashboard'),
#     path('progress/', dash_views.progress_view, name='progress'),
    
#     # Lesson and XP URLs
#     path('chatbot/', dash_views.chatbot_view, name='chatbot'),
#     path('lesson/go-bag/', dash_views.lesson_two_view, name='lesson-two'),
#     path('lesson/complete/1/', dash_views.complete_lesson_1_view, name='complete-lesson-1'),
#     path('lesson/get-xp/', dash_views.get_xp_view, name='get_xp'),
#     path('lesson/quiz-results/', dash_views.quiz_results_view, name='quiz_results'),

#     # Auth URLs
#     path('portal/login/', user_views.login_page_view, name='login_page'),
#     path('portal/register/student/', user_views.student_register_view, name='student_register'),
#     path('portal/login/student/', user_views.student_login_view, name='student_login'),
#     path('portal/logout/', user_views.user_logout_view, name='logout'),
# ]

from django.contrib import admin
from django.urls import path
from users import views as user_views       # Import the views from 'users' app
from dashboard import views as dash_views  # Import the views from 'dashboard' app

urlpatterns = [
    # Admin Panel
    path('admin/', admin.site.urls),
    
    # Main Dashboard and Progress Page
    path('', dash_views.dashboard_view, name='dashboard'),
    path('progress/', dash_views.progress_view, name='progress'),
    
    # Lesson, Drill, and XP URLs
    path('chatbot/', dash_views.chatbot_view, name='chatbot'),
    path('lesson/go-bag/', dash_views.lesson_two_view, name='lesson-two'),
    path('lesson/complete/1/', dash_views.complete_lesson_1_view, name='complete-lesson-1'),
    path('lesson/complete/2/', dash_views.complete_lesson_2_view, name='complete-lesson-2'),
    path('lesson/get-xp/', dash_views.get_xp_view, name='get_xp'),
    path('lesson/quiz-results/', dash_views.quiz_results_view, name='quiz_results'),
    path('drill/hurricane/', dash_views.hurricane_drill_view, name='hurricane-drill'),

    # Auth URLs
    path('portal/login/', user_views.login_page_view, name='login_page'),
    path('portal/register/student/', user_views.student_register_view, name='student_register'),
    path('portal/login/student/', user_views.student_login_view, name='student_login'),
    path('portal/logout/', user_views.user_logout_view, name='logout'),
]