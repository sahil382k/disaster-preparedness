from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from dashboard.models import UserProfile # Import the UserProfile model

@login_required
def leaderboard(request):
    # Fetch all user profiles, order them by points in descending order
    leaders = UserProfile.objects.all().order_by('-points')
    
    context = {
        'leaders': leaders,
    }
    return render(request, 'gamification/leaderboard.html', context)