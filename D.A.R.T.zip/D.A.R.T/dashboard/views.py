from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.views.decorators.clickjacking import xframe_options_sameorigin 

@login_required(login_url='login_page') 
def dashboard_view(request):
    """
    This serves the main index.html dashboard.
    """
    if request.user.user_type != 'student':
        messages.error(request, 'Access Denied. This dashboard is for students.')
        return redirect('logout') 

    context = {
        'full_name': request.user.first_name,
        'student_id': request.user.student_id,
        'points': request.user.total_points,        
        'modules': request.user.modules_completed   
    }
    return render(request, 'index.html', context)


@xframe_options_sameorigin  
def chatbot_view(request):
    """
    This view simply serves your intel.html chatbot page.
    """
    return render(request, 'intel.html')


@login_required(login_url='login_page') 
def lesson_two_view(request):
    """
    This view serves your hard-coded lesson page 'two.html'.
    """
    return render(request, 'two.html')


@login_required(login_url='login_page')
def complete_lesson_1_view(request):
    # This function is for "Lesson 1: Secure Your Space"
    user = request.user
    user.total_points += 50  
    user.modules_completed += 1
    user.save() 

    messages.success(request, 'Lesson 1 Complete! +50 Points!')
    return redirect('/#modules') 


@login_required(login_url='login_page')
def complete_lesson_2_view(request):
    # This function is for "Lesson 2: Go-Bag Essentials"
    user = request.user

    user.total_points += 100 
    user.modules_completed += 1
    user.save() 

    messages.success(request, 'Lesson 2 Complete! +100 Points!')
    return redirect('/#modules')