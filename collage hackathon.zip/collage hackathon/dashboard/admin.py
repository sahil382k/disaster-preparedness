from django.contrib import admin
from .models import UserProfile  # Only import from this app

admin.site.register(UserProfile)