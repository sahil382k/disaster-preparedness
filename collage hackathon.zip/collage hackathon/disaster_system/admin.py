from django.contrib import admin
from django.contrib.auth.models import User, Group
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.utils.html import format_html

# Customize the Admin Site
admin.site.site_header = 'Disaster Preparedness System Administration'
admin.site.site_title = 'Disaster Preparedness System'
admin.site.index_title = 'Welcome to Disaster Preparedness System Admin'

# Import models from all apps
from dashboard.models import UserProfile
from modules.models import Module, Question, Answer
from drills.models import Drill, DrillParticipation
from alerts.models import EmergencyContact, Alert
from gamification.models import Badge, UserBadge

# Custom User Admin to include UserProfile
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'User Profile'
    fk_name = 'user'

class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline, )
    list_display = ('username', 'email', 'first_name', 'last_name', 'get_role', 'get_school', 'is_staff')
    list_select_related = ('userprofile', )
    
    def get_role(self, instance):
        return instance.userprofile.role
    get_role.short_description = 'Role'
    
    def get_school(self, instance):
        return instance.userprofile.school
    get_school.short_description = 'School'
    
    def get_inline_instances(self, request, obj=None):
        if not obj:
            return list()
        return super().get_inline_instances(request, obj)

# Custom Group Admin
class CustomGroupAdmin(GroupAdmin):
    list_display = ('name', 'get_user_count')
    
    def get_user_count(self, obj):
        return obj.user_set.count()
    get_user_count.short_description = 'Number of Users'

# Module Admin
class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 4
    fields = ('text', 'is_correct', 'order')
    ordering = ('order',)

class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text_preview', 'module', 'order', 'answer_count')
    list_filter = ('module',)
    inlines = [AnswerInline]
    ordering = ('module', 'order')
    
    def text_preview(self, obj):
        return obj.text[:50] + '...' if len(obj.text) > 50 else obj.text
    text_preview.short_description = 'Question'
    
    def answer_count(self, obj):
        return obj.answer_set.count()
    answer_count.short_description = 'Answers'

class ModuleAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'updated_at', 'is_active', 'question_count')
    list_filter = ('is_active', 'created_at')
    search_fields = ('title', 'description')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('-created_at',)
    
    def question_count(self, obj):
        return obj.question_set.count()
    question_count.short_description = 'Questions'

# Drill Admin
class DrillParticipationInline(admin.TabularInline):
    model = DrillParticipation
    extra = 1
    readonly_fields = ('completed_at',)
    fields = ('user', 'score', 'completed_at')

class DrillAdmin(admin.ModelAdmin):
    list_display = ('name', 'disaster_type', 'scheduled_date', 'duration', 'is_completed', 'participation_count')
    list_filter = ('disaster_type', 'is_completed', 'scheduled_date')
    search_fields = ('name',)
    readonly_fields = ('created_at',)
    inlines = [DrillParticipationInline]
    ordering = ('-scheduled_date',)
    
    def participation_count(self, obj):
        return obj.drillparticipation_set.count()
    participation_count.short_description = 'Participants'

# Alert Admin
class AlertAdmin(admin.ModelAdmin):
    list_display = ('message_preview', 'target_audience', 'sent_at', 'has_geo_fence')
    list_filter = ('target_audience', 'sent_at')
    readonly_fields = ('sent_at',)
    ordering = ('-sent_at',)
    
    def message_preview(self, obj):
        return obj.message[:50] + '...' if len(obj.message) > 50 else obj.message
    message_preview.short_description = 'Message'
    
    def has_geo_fence(self, obj):
        return bool(obj.geo_fence)
    has_geo_fence.short_description = 'Geo-fence'
    has_geo_fence.boolean = True

# Emergency Contact Admin
class EmergencyContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'number', 'formatted_number')
    search_fields = ('name', 'number')
    
    def formatted_number(self, obj):
        return format_html('<strong>{}</strong>', obj.number)
    formatted_number.short_description = 'Formatted Number'

# Gamification Admin
class UserBadgeInline(admin.TabularInline):
    model = UserBadge
    extra = 1
    readonly_fields = ('earned_at',)
    fields = ('user', 'badge', 'earned_at')

class BadgeAdmin(admin.ModelAdmin):
    list_display = ('name', 'points_required', 'modules_required', 'user_count')
    list_filter = ('points_required', 'modules_required')
    inlines = [UserBadgeInline]
    
    def user_count(self, obj):
        return obj.userbadge_set.count()
    user_count.short_description = 'Users Earned'

class UserBadgeAdmin(admin.ModelAdmin):
    list_display = ('user', 'badge', 'earned_at')
    list_filter = ('badge', 'earned_at')
    readonly_fields = ('earned_at',)
    ordering = ('-earned_at',)

# User Profile Admin
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'school', 'points', 'badge_count')
    list_filter = ('role', 'school')
    search_fields = ('user__username', 'user__first_name', 'user__last_name', 'school')
    
    def badge_count(self, obj):
        return obj.user.userbadge_set.count()
    badge_count.short_description = 'Badges'

# Drill Participation Admin
class DrillParticipationAdmin(admin.ModelAdmin):
    list_display = ('user', 'drill', 'score', 'completed_at', 'completion_status')
    list_filter = ('drill', 'completed_at')
    search_fields = ('user__username', 'drill__name')
    readonly_fields = ('completed_at',)
    
    def completion_status(self, obj):
        if obj.completed_at:
            return format_html('<span style="color: green;">✓ Completed</span>')
        return format_html('<span style="color: red;">✗ Incomplete</span>')
    completion_status.short_description = 'Status'

# Unregister default models and register with custom admins
admin.site.unregister(User)
admin.site.unregister(Group)

admin.site.register(User, CustomUserAdmin)
admin.site.register(Group, CustomGroupAdmin)

# Register all models with their custom admin classes
admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Module, ModuleAdmin)
admin.site.register(Question, QuestionAdmin)
admin.site.register(Answer)
admin.site.register(Drill, DrillAdmin)
admin.site.register(DrillParticipation, DrillParticipationAdmin)
admin.site.register(EmergencyContact, EmergencyContactAdmin)
admin.site.register(Alert, AlertAdmin)
admin.site.register(Badge, BadgeAdmin)
admin.site.register(UserBadge, UserBadgeAdmin)